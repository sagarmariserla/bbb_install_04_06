#!/bin/sh

#
# Installer
#
# Author: Kumara
#

set -e

PACKAGE_PATH=`dirname $0`

TAR_OPTS="-v"

INSTALL_PREFIX="sudo"

usage() {
	printf "Usage:\n"
	printf "$0 [Options] <deployment-path>\n"
	printf "Options:\n"
	printf "  --configure-rpi      Auto configure Raspberry Pi system & zipgateway.cfg.\n"
	printf "  --configure-android-zware   For preparing Android tarball only.\n"
}

#
# Utility functions
# FIXME: Get these utility function from config/config-common.sh instead of duplicating here
#

#
# Update Key-Value pair configuration directives (even if commented out)
#
# Note: Any use of backreference indices in 'replace_string' must start from '\5'. Those until '\4' are internally used.
#
# Updates the key value pair in following forms
#       key value
#       key=value
#       key = value
#       key =value
#       key= value
#
config_directive_update() {
	local config_file_path
	local key
	local match_string
	local replace_string
	local delimiter

	config_file_path="$1"
	key="$2"
	match_string="$3"
	replace_string="$4"
	delimiter="$5"

	# Use comma as default delimiter
	if [ "x${delimiter}" = "x" ]; then
		delimiter=","
	fi


	${INSTALL_PREFIX} sed -i \
		"s${delimiter}^\(\s*\)\(#\?\)\(\s*\)${key}\(\s\+\|\s*=\s*\)${match_string}${delimiter}\1\2\3${key}\4${replace_string}${delimiter}" \
		"${config_file_path}"
}

config_directive_get_value() {
	local config_file_path
	local key
	local match_string
	local value_string
	local delimiter
	local value

	config_file_path="$1"
	key="$2"
	match_string="$3"
	value_string="$4"
	delimiter="$5"

	# Use comma as default delimiter
	if [ "x${delimiter}" = "x" ]; then
		delimiter=","
	fi

	value=`${INSTALL_PREFIX} grep "^\s*\(#\?\|;\?\)\s*${key}\(\s\+\|\s*=\s*\)${match_string}" ${config_file_path} \
		| sed \
		"s${delimiter}^\(\s*\)\(#\?\|;\?\)\(\s*\)${key}\(\s\+\|\s*=\s*\)${match_string}${delimiter}${value_string}${delimiter}"`

	printf "${value}"

	# Empty string ("") indicates no match
}

config_directive_is_enabled() {
	local config_file_path
	local key
	local match_string

	config_file_path="$1"
	key="$2"
	match_string="$3"

	if [ "x${match_string}" != "x" ]; then
		match_string="\(\s\+\|\s*=\s*\)${match_string}"
	fi

	${INSTALL_PREFIX} grep -q "^\s*${key}${match_string}" "${config_file_path}"

	# return status of last command is returned
}

config_directive_enable() {
	local config_file_path
	local key
	local match_string
	local delimiter

	config_file_path="$1"
	key="$2"
	match_string="$3"
	delimiter="$4"

	if [ "x${match_string}" != "x" ]; then
		match_string="\(\s\+\|\s*=\s*\)${match_string}"
	fi

	# Use comma as default delimiter
	if [ "x${delimiter}" = "x" ]; then
		delimiter=","
	fi

	${INSTALL_PREFIX} sed -i \
		"s${delimiter}^\(\s*\)\(#\?\|;\?\)\(\s*\)${key}\(${match_string}\)${delimiter}\1\3${key}\4${delimiter}" \
		"${config_file_path}"
}

config_directive_disable() {
	local config_file_path
	local key
	local match_string
	local delimiter
	local disable_char

	config_file_path="$1"
	key="$2"
	match_string="$3"
	delimiter="$4"
	disable_char="$5"

	if [ "x${match_string}" != "x" ]; then
		match_string="\(\s\+\|\s*=\s*\)${match_string}"
	fi

	# Use comma as default delimiter
	if [ "x${delimiter}" = "x" ]; then
		delimiter=","
	fi

	# Use comma as default delimiter
	if [ "x${disable_char}" = "x" ]; then
		disable_char="#"
	fi

	${INSTALL_PREFIX} sed -i \
		"s${delimiter}^\(\s*\)\(#\?\|;\?\)\(\s*\)${key}\(${match_string}\)${delimiter}\1${disable_char}\3${key}\4${delimiter}" \
		"${config_file_path}"
}

#
# End of Utility functions
#

arch_validate() {
	local arch_init
	local arch_zware
	local yes_no
	local OBJDUMP_BIN

	if [ "x${CONFIGURE_ANDROID_ZWARE_SYSTEM}" = "xyes" ]; then
		return
	fi

	OBJDUMP_BIN=$(command -v objdump 2>/dev/null || true)
	if [ "x${OBJDUMP_BIN}" = "x" ]; then
		echo "INFO: package architecture check is skipped."
		return
	fi

	arch_init=`objdump -f "/sbin/init" | grep architecture`

	${INSTALL_PREFIX} tar ${TAR_OPTS} -x -f "${PACKAGE_PATH}/installer-data.tar" -C "/tmp" \
		--strip-components=3 --wildcards "install/zwportald/bin/zwportald*"

	arch_zware=`objdump -f "/tmp/zwportald" | grep architecture`
	${INSTALL_PREFIX} rm -f "/tmp/zwportald"*

	if echo ${arch_init} | grep -q "x86-64"; then
		if ! echo ${arch_zware} | grep -q "x86-64"; then
			read -p "Warning: architecture mismatch. OS architecture: x86-64 ; Application built for ${arch_zware}. Continue installation [y/N]? : " yes_no

			if [ "x${yes_no}" != "xy" ] && [ "x${yes_no}" != "xY" ]; then
				exit 1
			fi
		fi
	else
		if echo ${arch_zware} | grep -q "x86-64"; then
			printf "Error: architecture mismatch. OS architecture: ${arch_zware} ; Application built for x86-64\n"
			exit 1
		fi
	fi
}

input_validate() {
	local yes_no

	#TODO: Check if the current used is part of sudo group

	if [ $# -lt 1 ]; then
		usage
		exit 1
	fi

	CONFIGURE_BEAGLEBONE_SYSTEM="no"
	CONFIGURE_ANDROID_ZWARE_SYSTEM="no"

	if [ "x$1" = "x--configure-beaglebone" ] || [ "x$1" = "x--configure-rpi" ]; then
		CONFIGURE_BEAGLEBONE_SYSTEM="yes"
		shift
	fi

	if [ "x$1" = "x--configure-android-zware" ]; then
		CONFIGURE_ANDROID_ZWARE_SYSTEM="yes"
		shift
	fi

	arch_validate

	DEPLOY_PATH=$1

	if [ "x${DEPLOY_PATH}" = "x" ]; then
		usage
		exit 1
	fi

	if [ ! -d ${DEPLOY_PATH} ]; then
		#read -p "Directory '${DEPLOY_PATH}' does not exist. Create? [Y/n]" yes_no
		#case $yes_no in
			#[Nn]*) exit 1 ;;
			#*) 
		sudo mkdir -p "${DEPLOY_PATH}"
		#esac
	fi
}

openldap_dit_save() {
	${INSTALL_PREFIX} tar ${TAR_OPTS} -x -f "${PACKAGE_PATH}/installer-data.tar" -C "${DEPLOY_PATH}" \
		"install/openldap/scripts/ldap-common.sh" \
		"install/openldap/scripts/ldap-save.sh"

	${INSTALL_PREFIX} "${DEPLOY_PATH}/install/openldap/scripts/ldap-save.sh"
}

openldap_dit_restore() {
	${INSTALL_PREFIX} "${DEPLOY_PATH}/install/openldap/scripts/ldap-restore.sh" || true
}

ldap_db_fetch() {
	local ldap_backend

	if [ ! -f "${DEPLOY_PATH}/install/openldap/etc/openldap/slapd.conf" ]; then
		return
	fi

	ldap_backend=`config_directive_get_value "${DEPLOY_PATH}/install/openldap/etc/openldap/slapd.conf" database \
		"\(.*\)" \
		"\5"`

	printf "Current LDAP backend: ${ldap_backend}\n"

	if [ "x${ldap_backend}" = "xbdb" ]; then
		openldap_dit_save
	fi
}

ldap_db_restore() {
	local ldap_backend

	ldap_backend=`config_directive_get_value "${DEPLOY_PATH}/install/openldap/etc/openldap/slapd.conf" database \
		"\(.*\)" \
		"\5"`

	if [ "x${ldap_backend}" = "xbdb" ]; then
		printf "LDAP backend: ${ldap_backend} -> mdb\n"

		# database
		config_directive_update "${DEPLOY_PATH}/install/openldap/etc/openldap/slapd.conf" database \
			".*" \
			"mdb" "/"

		openldap_dit_restore
	fi
}

#
# Fetch the current LDAP auth password configurations before the files get overwritten during 'install_data_extract()'
#
ldap_auth_password_fetch() {
	printf "Fetching current LDAP and SMTP mail password configurations...\n"

	if [ -f "${DEPLOY_PATH}/install/zwportald/etc/zwportald.conf" ]; then
		LDAP_AUTH_PASSWORD_ZWPORTALD_CONF=`config_directive_get_value "${DEPLOY_PATH}/install/zwportald/etc/zwportald.conf" password \
			"\"\(.*\)\"\s*$" \
			"\5"`
	fi

	if [ -f "${DEPLOY_PATH}/install/zweb/htdocs/register/config.php" ]; then
		LDAP_AUTH_PASSWORD_ZWEB_ADMIN_CONF=`${INSTALL_PREFIX} grep "define(\"LDAP_PHP_ADMIN_PASSWORD\",\(\s*\)\"\(.*\)\"" \
			"${DEPLOY_PATH}/install/zweb/htdocs/register/config.php" \
			| sed \
			"s/define(\"LDAP_PHP_ADMIN_PASSWORD\",\(\s*\)\"\(.*\)\".*/\2/"`
	fi

	if [ -f "${DEPLOY_PATH}/install/zweb/htdocs/register/config.php" ]; then
		SMTP_MAIL_PASSWORD_CONF=`${INSTALL_PREFIX} grep "define(\"SMTP_MAIL_PASSWORD\",\(\s*\)\"\(.*\)\"" \
			"${DEPLOY_PATH}/install/zweb/htdocs/register/config.php" \
			| sed \
			"s/define(\"SMTP_MAIL_PASSWORD\",\(\s*\)\"\(.*\)\".*/\2/"`
	fi
}

#
# Restore the LDAP auth password configurations that got overwritten during 'install_data_extract()'
#
ldap_auth_password_restore() {
	printf "Restoring LDAP and SMTP mail password configurations...\n"

	if [ "x${LDAP_AUTH_PASSWORD_ZWPORTALD_CONF}" != "x" ]; then
		config_directive_update "${DEPLOY_PATH}/install/zwportald/etc/zwportald.conf" password \
			"\".*\"" \
			"\"${LDAP_AUTH_PASSWORD_ZWPORTALD_CONF}\"" ";"
	fi

	if [ "x${LDAP_AUTH_PASSWORD_ZWEB_ADMIN_CONF}" != "x" ]; then
		${INSTALL_PREFIX} sed -i \
			"s;define(\"LDAP_PHP_ADMIN_PASSWORD\",\(\s*\)\"\(.*\)\";define(\"LDAP_PHP_ADMIN_PASSWORD\",\1\"${LDAP_AUTH_PASSWORD_ZWEB_ADMIN_CONF}\";" \
			"${DEPLOY_PATH}/install/zweb/htdocs/register/config.php"
	fi

	if [ "x${SMTP_MAIL_PASSWORD_CONF}" != "x" ]; then
		${INSTALL_PREFIX} sed -i \
			"s;define(\"SMTP_MAIL_PASSWORD\",\(\s*\)\"\(.*\)\";define(\"SMTP_MAIL_PASSWORD\",\1\"${SMTP_MAIL_PASSWORD_CONF}\";" \
			"${DEPLOY_PATH}/install/zweb/htdocs/register/config.php"
	fi

}

#
# Fetch the current enabled/disabled state of CA Certificate configuration in HTTP Server (zweb)before the file gets
# overwritten during 'install_data_extract()'
#
zweb_ca_certificate_enable_state_fetch() {
	# Enabled by default
	ZWEB_CA_CERTIFICATE_ENABLED=1

	if [ -f "${DEPLOY_PATH}/install/httpd/conf/zwave/httpd-zweb.conf" ]; then
		if ! config_directive_is_enabled "${DEPLOY_PATH}/install/httpd/conf/zwave/httpd-zweb.conf" SSLCertificateChainFile ".*$" ; then
			ZWEB_CA_CERTIFICATE_ENABLED=0
		fi
	fi
}

#
# Restore the enabled/disabled state of CA Certificate configuration in HTTP Server (zweb)
# that got overwritten during 'install_data_extract()'
#
zweb_ca_certificate_enable_state_restore() {
	if [ "x${ZWEB_CA_CERTIFICATE_ENABLED}" = "x0" ]; then
		config_directive_disable "${DEPLOY_PATH}/install/httpd/conf/zwave/httpd-zweb.conf" SSLCertificateChainFile ".*$"
	else
		config_directive_enable "${DEPLOY_PATH}/install/httpd/conf/zwave/httpd-zweb.conf" SSLCertificateChainFile ".*$"
	fi
}


pre_install_action() {
	if [ -f "${DEPLOY_PATH}/service/service.sh" ]; then
		printf "Stopping services...\n"

		"${DEPLOY_PATH}/service/service.sh" stop || true
	fi

	#ldap_db_fetch

	#ldap_auth_password_fetch

	zweb_ca_certificate_enable_state_fetch
}

post_install_action() {
	zweb_ca_certificate_enable_state_restore

	#ldap_auth_password_restore

	#ldap_db_restore
}

install_device_db() {
	local new_major_version
	local new_minor_version
	local current_major_version
	local current_minor_version

	# Get new version
	${INSTALL_PREFIX} tar ${TAR_OPTS} -x -f "${PACKAGE_PATH}/installer-data.tar" -C "/tmp" \
		 --strip-components=3 "install/zwportald/etc/schema_version.txt"
	new_major_version=`grep "^MAJOR=" /tmp/schema_version.txt | tr -d '\r\n' | sed "s/^MAJOR=\([0-9]*\).*/\1/"`
	new_minor_version=`grep "^MINOR=" /tmp/schema_version.txt | tr -d '\r\n' | sed "s/^MINOR=\([0-9]*\).*/\1/"`

	# Get current version
	current_major_version=""
	current_minor_version=""
	if [ -f "${DEPLOY_PATH}/install/zwportald/etc/schema_version.txt" ]; then
		current_major_version=`grep "^MAJOR=" "${DEPLOY_PATH}/install/zwportald/etc/schema_version.txt" \
			| tr -d '\r\n' | sed "s/^MAJOR=\([0-9]*\).*/\1/"`
		current_minor_version=`grep "^MINOR=" "${DEPLOY_PATH}/install/zwportald/etc/schema_version.txt" \
			| tr -d '\r\n' | sed "s/^MINOR=\([0-9]*\).*/\1/"`
	fi
	if [ "x${current_major_version}" = "x" ]; then
		current_major_version=0
	fi
	if [ "x${current_minor_version}" = "x" ]; then
		current_minor_version=0
	fi

	echo "Device DB - schema - current version:${current_major_version}.${current_minor_version} new version:${new_major_version}.${new_minor_version}"

	# Overwrite DB if major numbers of new and current version don't match. If these numbers do match,
	# overwrite DB only if new minor version is greater than or equal to current minor version.
	if [ "${new_major_version}" -ne "${current_major_version}" ] || [ "${new_minor_version}" -ge "${current_minor_version}" ]; then
		${INSTALL_PREFIX} rm -rf "${DEPLOY_PATH}/install/zwportald/etc/zwave_device_rec.txt"
		${INSTALL_PREFIX} rm -rf "${DEPLOY_PATH}/install/zwportald/etc/schema_version.txt"
		${INSTALL_PREFIX} tar ${TAR_OPTS} -x -f "${PACKAGE_PATH}/installer-data.tar" -C "${DEPLOY_PATH}" \
			--wildcards "install/zwportald/etc/zwave_device_rec.txt"
		${INSTALL_PREFIX} tar ${TAR_OPTS} -x -f "${PACKAGE_PATH}/installer-data.tar" -C "${DEPLOY_PATH}" \
			--wildcards "install/zwportald/etc/schema_version.txt"
		echo "Device DB - overwritten"
	else
		echo "Device DB - not overwritten"
	fi
}

install_data_extract() {
	local skip_old_files_option
	local lines

	printf "Extracting install data...\n"

	# In 'tar' utility v1.26, --skip-old-files option is not supported. --keep-old-files option does not exit with error when files already exist.
	# In 'tar' utility v1.27, --skip-old-files option is supported and does not exit with error when files already exist. --keep-old-files option exit with error when files already exist.
	# So, --skip-old-files option is used if supported. If not, --keep-old-files option is used.
	if tar --help | grep -q "skip-old-files" ; then
		skip_old_files_option="--skip-old-files"
	else
		skip_old_files_option="--keep-old-files"
	fi

	# Extract overwritable files/directories
	${INSTALL_PREFIX} tar ${TAR_OPTS} -x -f "${PACKAGE_PATH}/installer-data.tar" -C "${DEPLOY_PATH}" \
		--wildcards --exclude "install/zwportald/etc/zwave_device_rec.txt" \
		--exclude "install/zwportald/etc/schema_version.txt" \
		--exclude-from "${PACKAGE_PATH}/untar-no-overwrite-file.list"

	lines=`cat "${PACKAGE_PATH}/untar-no-overwrite-file.list" | wc -l`
	if [ "x${lines}" != "x0" ]; then
	# Extract non-overwritable files/directories
	${INSTALL_PREFIX} tar ${TAR_OPTS} -x -f "${PACKAGE_PATH}/installer-data.tar" -C "${DEPLOY_PATH}" \
		${skip_old_files_option} \
		--wildcards \
		`cat "${PACKAGE_PATH}/untar-no-overwrite-file.list"`
	fi

	lines=`cat "${PACKAGE_PATH}/untar-no-overwrite-file-exception.list" | wc -l`
	if [ "x${lines}" != "x0" ]; then
	# Extract overwritable files/directories within non-overwritable directories (covered under 'untar-no-overwrite-file.list')
	${INSTALL_PREFIX} tar ${TAR_OPTS} -x -f "${PACKAGE_PATH}/installer-data.tar" -C "${DEPLOY_PATH}" \
		`cat "${PACKAGE_PATH}/untar-no-overwrite-file-exception.list"`
	fi

	install_device_db
}

install_data_apply_ownership() {
	local file
	local user
	local group

	user=`id -un`
	group=`id -gn`

	printf "Applying ownership ${user}:${group} to selected files...\n"

	if [ "x${DEPLOY_PATH}" = "x" ]; then
		printf "Error: Attempted to change ownership at root(/) directory\n"
		exit 1
	fi

	for file in `cat "${PACKAGE_PATH}/file-non-root.list"`; do
		printf "${file}\n"
		if [ "${file}" = "install/zweb/etc/usrname" ]; then
			${INSTALL_PREFIX} chown -R daemon:daemon "${DEPLOY_PATH}/${file}"
			${INSTALL_PREFIX} chmod og-rwx "${DEPLOY_PATH}/${file}"
		else
			${INSTALL_PREFIX} chown -R ${user}:${group} "${DEPLOY_PATH}/${file}"
		fi
	done
}

configuration_get() {
	printf "Getting configuration...\n"

	"${DEPLOY_PATH}/config/config-config.sh" prompt-missing-only
}

configuration_apply() {
	printf "Applying configuration...\n"

	"${DEPLOY_PATH}/config/configure.sh" configure

	if [ "x${CONFIGURE_BEAGLEBONE_SYSTEM}" = "xyes" ]; then
		"${DEPLOY_PATH}/config/configure.sh" --configure-rpi
	fi
}

install_upstart_configuration() {
	local config_dir
	local service
	local yes_no

	if [ "x${CONFIGURE_ANDROID_ZWARE_SYSTEM}" = "xyes" ]; then
		return
	fi

	config_dir="/etc/init"

	printf "Adding Z-Ware services to 'upstart' service manager...\n"

	for service in `ls -1 "${DEPLOY_PATH}/install/upstart/"*\.conf` ; do
		service=`basename ${service} | cut -d '.' -f1`

		if [ ! -f "${config_dir}/${service}.conf" ]; then
			#read -p "Add '${service}' service to upstart configuration directory '${config_dir}' [y/N]? : " yes_no
			yes_no=""
		else
			yes_no="y"
		fi

		if [ "x${yes_no}" = "xy" ] || [ "x${yes_no}" = "xY" ]; then
			printf "Installing upstart service configuration for '${service}'\n"
			${INSTALL_PREFIX} cp "${DEPLOY_PATH}/install/upstart/${service}.conf" "${config_dir}/"
		fi
	done
}

install_autostart_configuration() {
	local user
	local yes_no
	local default_yes_no
	local default_yes_no_str

	user=`id -un`

	# Update occurrences of INSTALL_PATH
	${INSTALL_PREFIX} sed -i "s:<BASE_PATH>:${DEPLOY_PATH}:g" \
		"${DEPLOY_PATH}/config/zware-service"

	# Update User
	${INSTALL_PREFIX} sed -i "s:<USER>:${user}:g" \
		"${DEPLOY_PATH}/config/zware-service"

	if [ "x${CONFIGURE_ANDROID_ZWARE_SYSTEM}" = "xyes" ]; then
		return
	fi

	if [ -f "${DEPLOY_PATH}/config/PRODUCT" ]; then
	. "${DEPLOY_PATH}/config/PRODUCT"
	fi

	if [ "x${TARGET_PLATFORM}" = "xbeaglebone" ]; then
		default_yes_no="y"
		default_yes_no_str="Y/n"
	else
		default_yes_no="n"
		default_yes_no_str="y/N"
	fi

	#read -p "Enable this package to be auto started after system boot up (${default_yes_no_str})? : " yes_no
	#yes_no="${yes_no:-$default_yes_no}"
	yes_no="Y"
	if [ "x${yes_no}" = "xy" ] || [ "x${yes_no}" = "xY" ]; then
		${INSTALL_PREFIX} cp "${DEPLOY_PATH}/config/zware-service" "/etc/init.d/"

		if ! ${INSTALL_PREFIX} update-rc.d zware-service defaults 2>> ${DEPLOY_PATH}/config/config.log >&2 ; then
			printf "'update-rc.d zware-service defaults' failed with non-zero status. continuing...\n"
		fi

	else
		if ! ${INSTALL_PREFIX} update-rc.d -f zware-service remove 2>> ${DEPLOY_PATH}/config/config.log >&2 ; then
			printf "'update-rc.d -f zware-service remove' failed with non-zero status. continuing...\n"
		fi

		${INSTALL_PREFIX} rm -f "/etc/init.d/zware-service"
	fi
}

finish_message() {
	printf "Z-Ware Portal ver %s from package %s is installed!\n" "$(cat ${DEPLOY_PATH}/install/zwportald/VERSION)" "$(tail -n 1 ${DEPLOY_PATH}/install/build.info)"
}

user_validate() {
	# Do not allow root user to install as the httpd will be run using user "daemon".
	# User "daemon" will not have access permission to root user installed directory.

	local usr_group

	usr_group=`id -g -n`

	if [ "$usr_group" = "" ]; then
		echo "Can't determine the user group, please make sure command 'id -g -n' is supported."
		exit 1
	fi

	if [ "$usr_group" = "root" ]; then
		echo "Please login as non-root user to install this application."
		exit 1
	fi

}

disable_beaglebone_sysservice() {
	# Disable certain beaglebone system service to free up the port resource for zware.

	local usr_group

	if [ "x${TARGET_PLATFORM}" != "xbeaglebone" ]; then
		return
	fi


	echo "Checking system port resource are available..."

set +e
	# On SD card, these commands will have errors
	${INSTALL_PREFIX} systemctl stop apache2.service 2>> ${DEPLOY_PATH}/config/config.log >&2
	${INSTALL_PREFIX} systemctl stop bonescript-autorun.service 2>> ${DEPLOY_PATH}/config/config.log >&2
	${INSTALL_PREFIX} systemctl stop bonescript.service 2>> ${DEPLOY_PATH}/config/config.log >&2
	${INSTALL_PREFIX} systemctl stop bonescript.socket 2>> ${DEPLOY_PATH}/config/config.log >&2

	${INSTALL_PREFIX} update-rc.d -f apache2 disable 2>> ${DEPLOY_PATH}/config/config.log >&2
	${INSTALL_PREFIX} update-rc.d -f apache2.service remove 2>> ${DEPLOY_PATH}/config/config.log >&2
	${INSTALL_PREFIX} systemctl disable bonescript-autorun.service 2>> ${DEPLOY_PATH}/config/config.log >&2
	${INSTALL_PREFIX} systemctl disable bonescript.service 2>> ${DEPLOY_PATH}/config/config.log >&2
	${INSTALL_PREFIX} systemctl disable bonescript.socket 2>> ${DEPLOY_PATH}/config/config.log >&2
set -e

	echo "Checking system port resource completed."
}

create_empty_service_log() {
	#create an empty service.log
	touch ${DEPLOY_PATH}/service.log > /dev/null 2>&1
}

user_validate

input_validate $@

pre_install_action

install_data_extract

install_data_apply_ownership

post_install_action

configuration_get

configuration_apply

install_upstart_configuration

install_autostart_configuration

disable_beaglebone_sysservice

create_empty_service_log

finish_message

